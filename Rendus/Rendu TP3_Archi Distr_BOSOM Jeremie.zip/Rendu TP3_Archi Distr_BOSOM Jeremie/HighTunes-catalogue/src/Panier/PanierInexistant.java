package Panier;
import java.rmi.RemoteException;

public class PanierInexistant extends RemoteException
{
	private static final long serialVersionUID = 1L;	
}
