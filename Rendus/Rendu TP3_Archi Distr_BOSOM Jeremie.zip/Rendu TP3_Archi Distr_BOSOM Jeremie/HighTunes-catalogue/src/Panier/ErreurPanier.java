package Panier;
import java.rmi.RemoteException;

public class ErreurPanier extends RemoteException
{
	private static final long serialVersionUID = 1L;	
}
