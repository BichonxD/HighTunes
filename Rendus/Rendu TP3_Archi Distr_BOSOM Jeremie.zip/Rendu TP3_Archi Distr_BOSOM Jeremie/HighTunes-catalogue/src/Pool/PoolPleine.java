package Pool;

public class PoolPleine extends ErreurPool
{
	private static final long serialVersionUID = 1L;	
}
