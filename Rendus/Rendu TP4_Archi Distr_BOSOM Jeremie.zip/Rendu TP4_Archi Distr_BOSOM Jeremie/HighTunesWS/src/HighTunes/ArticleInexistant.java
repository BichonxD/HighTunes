package HighTunes;

@SuppressWarnings("serial")
public class ArticleInexistant extends Exception
{
}
