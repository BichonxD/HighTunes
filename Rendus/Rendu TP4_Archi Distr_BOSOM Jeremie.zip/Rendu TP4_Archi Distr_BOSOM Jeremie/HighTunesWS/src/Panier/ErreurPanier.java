package Panier;

@SuppressWarnings("serial")
public class ErreurPanier extends Exception
{
}
