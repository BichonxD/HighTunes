package Panier;

@SuppressWarnings("serial")
public class PanierInexistant extends Exception
{
}
