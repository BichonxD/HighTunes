import java.rmi.RemoteException;

public class ArticleInexistant extends RemoteException
{
	private static final long serialVersionUID = 1L;
}
